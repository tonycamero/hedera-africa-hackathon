# Warp Sprint: Persona Consolidation

- P0_init_branch_and_tags.yaml
- P1_persona_config_system.yaml
- P2_persona_aware_router.yaml
- P3_envelope_and_migration.yaml
- P4_pro_theme_and_service.yaml
- P5_recognition_factory.yaml
- P6_5_merge_dependencies.yaml
- P6_catalog_consolidation.yaml
- P7_persona_test_matrix.yaml
- P8_preview_envs_and_pr.yaml
- P9_5_hcs21_review.yaml
- P9_cleanup.yaml
